package com.virtusa.spring.employee.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.spring.employee.dao.EmployeeDAOImpl;
import com.virtusa.spring.employee.entity.Employee;


public class EmployeeMain {

	public static void main(String[] args) {
	
		ApplicationContext context= new ClassPathXmlApplicationContext("spring-core-employee.xml");
	    EmployeeDAOImpl dao = context.getBean("empDAOImpl",EmployeeDAOImpl.class);
//	    
//	    Employee employee = context.getBean("employee",Employee.class);
//	    
//	    System.out.println(employee);
	    Employee employee= new Employee();
	    
	    employee.setEmpId(4);
	    employee.setEmpName("arav");
	    employee.setEmpSal(40000);
//	    
//	    int s = dao.insertEmployee(employee);
//	    System.out.println(s);
	    
//	    Employee s = dao.updateEmployee(employee);
//	    System.out.println(s);
	    
//	   Employee s = dao.searchEmployee(4);
//	   System.out.println(s);
	    
	    List<Employee> s = dao.getAllEmployees();
	    for(Employee e:s)
	    {
	    	System.out.println(e);
	    }
	    
//	    dao.deleteEmployee(4);
	    
	    
	    
	    
	    


	}

}
