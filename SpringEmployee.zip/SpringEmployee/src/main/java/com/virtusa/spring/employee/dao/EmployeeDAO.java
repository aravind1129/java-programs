package com.virtusa.spring.employee.dao;

import com.virtusa.spring.employee.entity.Employee;

public interface EmployeeDAO {

	String insertEmployee(Employee employee);

	String updateEmployee(Employee employee);

	Employee searchEmployee(int empId);

	String deleteEmployee(int empID);
	
	

	
	

}
