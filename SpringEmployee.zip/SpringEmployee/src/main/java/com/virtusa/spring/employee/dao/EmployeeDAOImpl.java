package com.virtusa.spring.employee.dao;


import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.orm.hibernate5.HibernateTemplate;

import com.virtusa.spring.employee.entity.Employee;

public class EmployeeDAOImpl{
	
	
	private HibernateTemplate hibernateTemplate;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Transactional
	public int insertEmployee(Employee employee) {
		
		 return (Integer) hibernateTemplate.save(employee);
	}

	@Transactional
	public Employee updateEmployee(Employee employee) {
	
	hibernateTemplate.update(employee);
		return employee;
	}

	@Transactional
	public Employee searchEmployee(int empId) {
		
		return hibernateTemplate.get(Employee.class, empId);
	}

	@Transactional
	public void deleteEmployee(int empId) {
		
		Employee emp = hibernateTemplate.get(Employee.class, empId);
		hibernateTemplate.delete(emp);
	
	}
	
	public List<Employee> getAllEmployees()
	{
		return hibernateTemplate.loadAll(Employee.class);
		
	}
	
	


}
